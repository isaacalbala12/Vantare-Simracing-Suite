package derive

import (
	"math"
	"time"

	"github.com/vantare/overlays/v2/internal/telemetry/core"
	"github.com/vantare/overlays/v2/internal/telemetry/schema"
	"github.com/vantare/overlays/v2/internal/telemetry/schema/identity"
	"github.com/vantare/overlays/v2/internal/telemetry/schema/session"
	"github.com/vantare/overlays/v2/internal/telemetry/schema/standings"
)

type GapSet struct {
	Freshness schema.Freshness
	Vehicles  []VehicleGap
}

type VehicleGap struct {
	Vehicle identity.VehicleID
	Time    schema.Field[standings.RelativeTime]
	Laps    schema.Field[standings.RelativeLaps]
}

func deriveSessionRemaining(
	current schema.Field[time.Duration],
	end schema.Field[session.EndTime],
) schema.Field[session.RemainingTime] {
	quality, usable := exactFreshQuality(current, end)
	if !usable {
		if quality == schema.FreshnessInvalid {
			return invalidDerived[session.RemainingTime]()
		}
		return schema.MissingField[session.RemainingTime]()
	}
	currentValue, _ := current.Value()
	endValue, _ := end.Value()
	currentSeconds := float64(currentValue) / float64(time.Second)
	remaining := float64(endValue) - currentSeconds
	if currentValue < 0 || !isFinite(float64(endValue)) || remaining < 0 || !isFinite(remaining) {
		return invalidDerived[session.RemainingTime]()
	}
	return mustDerived(session.RemainingTime(remaining), quality)
}

func deriveRelativeGaps(
	playerID identity.VehicleID,
	playerPresent schema.Field[bool],
	vehicles []core.VehicleState,
	trackLength schema.Field[standings.LapDistance],
) GapSet {
	if playerID == "" {
		return GapSet{Freshness: schema.FreshnessMissing}
	}
	present, playerPresenceUsable := observedBool(playerPresent)
	if !playerPresenceUsable || !present {
		return GapSet{Freshness: schema.FreshnessMissing}
	}
	var player *core.VehicleState
	for index := range vehicles {
		if vehicles[index].Identity.Vehicle == playerID {
			player = &vehicles[index]
			break
		}
	}
	if player == nil {
		return GapSet{Freshness: schema.FreshnessMissing}
	}
	isPlayer, markerUsable := observedBool(player.Player)
	if !markerUsable || !isPlayer {
		return GapSet{Freshness: schema.FreshnessMissing}
	}

	result := GapSet{
		Freshness: schema.FreshnessFresh,
		Vehicles:  make([]VehicleGap, len(vehicles)),
	}
	for index, current := range vehicles {
		result.Vehicles[index] = deriveVehicleGap(*player, current, trackLength)
		result.Freshness = worstGapFreshness(result.Freshness, relevantGapFreshness(result.Vehicles[index]))
	}
	return result
}

func relevantGapFreshness(gap VehicleGap) schema.Freshness {
	return worstGapFreshness(gap.Laps.Freshness(), gap.Time.Freshness())
}

func worstGapFreshness(left, right schema.Freshness) schema.Freshness {
	rank := func(value schema.Freshness) int {
		switch value {
		case schema.FreshnessFresh:
			return 0
		case schema.FreshnessStale:
			return 1
		case schema.FreshnessMissing:
			return 2
		default:
			return 3
		}
	}
	if rank(right) > rank(left) {
		return right
	}
	return left
}

func deriveVehicleGap(player, current core.VehicleState, trackLength schema.Field[standings.LapDistance]) VehicleGap {
	result := VehicleGap{Vehicle: current.Identity.Vehicle}
	result.Laps = relativeProgressLaps(player, current, trackLength)

	timeQuality, timeUsable := exactFreshQuality(player.LapProgressTime, current.LapProgressTime)
	if !timeUsable {
		if timeQuality == schema.FreshnessInvalid {
			result.Time = invalidDerived[standings.RelativeTime]()
		} else {
			result.Time = schema.MissingField[standings.RelativeTime]()
		}
		return result
	}
	playerTime, _ := player.LapProgressTime.Value()
	currentTime, _ := current.LapProgressTime.Value()
	if !isFinite(float64(playerTime)) || !isFinite(float64(currentTime)) {
		result.Time = invalidDerived[standings.RelativeTime]()
		return result
	}
	if player.Identity.Vehicle == current.Identity.Vehicle {
		result.Time = mustDerived(standings.RelativeTime(0), timeQuality)
		return result
	}

	periodQuality, periodUsable := exactFreshQuality(player.LapProgressTime, player.EstimatedLapTime)
	if !periodUsable || periodQuality != timeQuality {
		if periodQuality == schema.FreshnessInvalid {
			result.Time = invalidDerived[standings.RelativeTime]()
		} else {
			result.Time = schema.MissingField[standings.RelativeTime]()
		}
		return result
	}
	period, _ := player.EstimatedLapTime.Value()
	if !isFinite(float64(period)) || period <= 0 {
		result.Time = invalidDerived[standings.RelativeTime]()
		return result
	}
	delta := float64(currentTime) - float64(playerTime)
	delta -= math.Round(delta/float64(period)) * float64(period)
	if !isFinite(delta) {
		result.Time = invalidDerived[standings.RelativeTime]()
		return result
	}
	result.Time = mustDerived(standings.RelativeTime(delta), timeQuality)
	return result
}

func exactFreshQuality[A, B comparable](left schema.Field[A], right schema.Field[B]) (schema.Freshness, bool) {
	if left.Freshness() == schema.FreshnessInvalid || right.Freshness() == schema.FreshnessInvalid {
		return schema.FreshnessInvalid, false
	}
	_, leftPresent := left.Value()
	_, rightPresent := right.Value()
	if (leftPresent && left.Provenance() != schema.ProvenanceObserved) ||
		(rightPresent && right.Provenance() != schema.ProvenanceObserved) {
		return schema.FreshnessInvalid, false
	}
	if !leftPresent || !rightPresent || left.Freshness() == schema.FreshnessMissing || right.Freshness() == schema.FreshnessMissing {
		return schema.FreshnessMissing, false
	}
	if left.Freshness() != right.Freshness() {
		return schema.FreshnessMissing, false
	}
	if left.Freshness() != schema.FreshnessFresh && left.Freshness() != schema.FreshnessStale {
		return schema.FreshnessInvalid, false
	}
	return left.Freshness(), true
}

func observedBool(field schema.Field[bool]) (bool, bool) {
	value, present := field.Value()
	return value, present && field.Provenance() == schema.ProvenanceObserved &&
		(field.Freshness() == schema.FreshnessFresh || field.Freshness() == schema.FreshnessStale)
}

func singleQuality[T comparable](field schema.Field[T]) schema.Freshness {
	_, present := field.Value()
	if !present {
		return schema.FreshnessMissing
	}
	if field.Provenance() != schema.ProvenanceObserved {
		return schema.FreshnessInvalid
	}
	return field.Freshness()
}

func invalidDerived[T comparable]() schema.Field[T] {
	var zero T
	return mustDerived(zero, schema.FreshnessInvalid)
}

func mustDerived[T comparable](value T, freshness schema.Freshness) schema.Field[T] {
	field, err := schema.NewField(value, schema.ProvenanceDerived, freshness)
	if err != nil {
		panic(err)
	}
	return field
}

func isFinite(value float64) bool {
	return !math.IsNaN(value) && !math.IsInf(value, 0)
}

// A rival is lapped relative to the player only after a full circuit of
// progress separates them. Subtracting each car's deficit to a third car
// (the leader) mislabels traffic around the leader's timing-line boundary.
func relativeProgressLaps(player, current core.VehicleState, trackLength schema.Field[standings.LapDistance]) schema.Field[standings.RelativeLaps] {
	quality, usable := exactFreshQuality(player.CompletedLaps, current.CompletedLaps)
	distanceQuality, distancesUsable := exactFreshQuality(player.LapDistance, current.LapDistance)
	lengthQuality := singleQuality(trackLength)
	if !usable || !distancesUsable || quality != distanceQuality || quality != lengthQuality {
		if quality == schema.FreshnessInvalid || distanceQuality == schema.FreshnessInvalid || lengthQuality == schema.FreshnessInvalid {
			return invalidDerived[standings.RelativeLaps]()
		}
		return schema.MissingField[standings.RelativeLaps]()
	}
	length, lengthPresent := trackLength.Value()
	playerDistance, _ := player.LapDistance.Value()
	currentDistance, _ := current.LapDistance.Value()
	playerLaps, _ := player.CompletedLaps.Value()
	currentLaps, _ := current.CompletedLaps.Value()
	if !lengthPresent || !isFinite(float64(length)) || length <= 0 || !isFinite(float64(playerDistance)) || !isFinite(float64(currentDistance)) || playerDistance < 0 || currentDistance < 0 || playerDistance >= length || currentDistance >= length || playerLaps < 0 || currentLaps < 0 {
		return invalidDerived[standings.RelativeLaps]()
	}
	difference := float64(int64(currentLaps)-int64(playerLaps)) + float64(currentDistance-playerDistance)/float64(length)
	if difference < math.MinInt32 || difference > math.MaxInt32 {
		return invalidDerived[standings.RelativeLaps]()
	}
	return mustDerived(standings.RelativeLaps(math.Trunc(difference)), quality)
}
