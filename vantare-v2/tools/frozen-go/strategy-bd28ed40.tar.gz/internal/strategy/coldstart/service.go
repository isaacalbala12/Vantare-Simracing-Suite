package coldstart

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/vantare/overlays/v2/internal/telemetryanalysis"
)

type Decision string

const (
	defaultImportConcurrency = 4
	maximumImportConcurrency = 4
	// Keep the existing 30-minute client budget, allowing a minute for the response.
	defaultCandidateTimeout      = 29 * time.Minute
	maxImportBatchEstimatedBytes = int64(4 << 30)
	importMemoryExpansionFactor  = int64(16)
	defaultImportMemoryEstimate  = int64(1 << 30)
)

func importMemoryEstimate(candidate telemetryanalysis.Candidate) int64 {
	if candidate.Size <= 0 {
		return defaultImportMemoryEstimate
	}
	return candidate.Size * importMemoryExpansionFactor
}

func selectPendingBatch(candidates []telemetryanalysis.Candidate, imported, failed map[string]struct{}, limit int) []telemetryanalysis.Candidate {
	pending := make([]telemetryanalysis.Candidate, 0, limit)
	var batchEstimate int64
	for _, candidate := range candidates {
		if _, exists := imported[candidate.Locator]; exists {
			continue
		}
		if _, exists := failed[candidate.Locator]; exists {
			continue
		}
		estimate := importMemoryEstimate(candidate)
		if len(pending) > 0 && batchEstimate+estimate > maxImportBatchEstimatedBytes {
			continue
		}
		pending = append(pending, candidate)
		batchEstimate += estimate
		if len(pending) == limit {
			break
		}
	}
	return pending
}

const (
	DecisionPending  Decision = "pending"
	DecisionAccepted Decision = "accepted"
	DecisionRejected Decision = "rejected"
)

type Status struct {
	Reason     string    `json:"reason,omitempty"`
	Recovered  bool      `json:"recovered,omitempty"`
	ShouldShow bool      `json:"shouldShow"`
	Checking   bool      `json:"checking"`
	Found      int       `json:"found"`
	Imported   int       `json:"imported"`
	Skipped    int       `json:"skipped"`
	Failures   []Failure `json:"failures"`
	Decision   Decision  `json:"decision"`
}

type Progress struct {
	Imported int       `json:"imported"`
	Skipped  int       `json:"skipped"`
	Total    int       `json:"total"`
	Done     bool      `json:"done"`
	Failures []Failure `json:"failures"`
}

type Failure struct {
	Locator string `json:"locator"`
	Reason  string `json:"reason"`
}

type SessionImporter interface {
	Import(context.Context, telemetryanalysis.Candidate) (telemetryanalysis.AuthorizedSessionModel, error)
}

type SessionStore interface {
	telemetryanalysis.AuthorizedSessionSource
	Add(context.Context, telemetryanalysis.AuthorizedSessionModel) error
}

type DiscoverFunc func(context.Context) ([]telemetryanalysis.Candidate, error)

type ServiceOptions struct {
	CatalogUnavailable bool
	CatalogRecovered   bool
	StatePath          string
	Discover           DiscoverFunc
	Importer           SessionImporter
	Store              SessionStore
	ImportConcurrency  int
	CandidateTimeout   time.Duration
}

type Service struct {
	recovered    bool
	mu           sync.Mutex
	options      ServiceOptions
	candidates   []telemetryanalysis.Candidate
	discovering  bool
	discoveryErr error
}

type persistedState struct {
	Decision         Decision  `json:"decision"`
	ImportedLocators []string  `json:"importedLocators"`
	Failures         []Failure `json:"failures"`
	Total            int       `json:"total"`
}

func NewService(options ServiceOptions) *Service {
	return &Service{options: options}
}

func (service *Service) Status(ctx context.Context) (status Status, err error) {
	// Defensa ante un receptor nulo: si el arranque no pudo construir el
	// servicio, el arranque en frío queda pendiente en vez de romper la app.
	if service == nil {
		return Status{Decision: DecisionPending, Failures: []Failure{}}, nil
	}
	service.mu.Lock()
	defer service.mu.Unlock()
	defer func() {
		if status.Failures == nil {
			status.Failures = []Failure{}
		}
		status.Recovered = service.recovered || service.options.CatalogRecovered
	}()
	if service.options.CatalogUnavailable {
		return Status{Decision: DecisionPending, Reason: "catalog_unavailable"}, nil
	}
	state, _, err := service.readReconciledState(ctx)
	if err != nil {
		reason := "state_unavailable"
		if errors.Is(err, errCatalogReconciliation) {
			reason = "catalog_unavailable"
		}
		return Status{Decision: DecisionPending, Reason: reason}, nil
	}
	if state.Decision == DecisionRejected {
		return statusFromState(state, false, false), nil
	}
	if state.Decision == DecisionAccepted {
		return statusFromState(state, len(state.Failures) > 0, false), nil
	}
	if service.options.Discover == nil || service.options.Importer == nil || service.options.Store == nil {
		return Status{Decision: DecisionPending, Reason: "importer_unavailable"}, nil
	}
	if service.candidates == nil {
		if service.discoveryErr != nil {
			return Status{}, service.discoveryErr
		}
		if !service.discovering {
			service.startDiscovery()
		}
		return statusFromState(state, true, true), nil
	}
	state.Total, _ = importCompletion(state, service.candidates)
	return statusFromState(state, len(service.candidates) > 0, false), nil
}

func (service *Service) ImportNext(ctx context.Context) (Progress, error) {
	service.mu.Lock()
	defer service.mu.Unlock()
	if service.options.CatalogUnavailable || service.options.Store == nil || service.options.Importer == nil {
		return Progress{}, fmt.Errorf("cold start import unavailable")
	}
	state, stored, err := service.readReconciledState(ctx)
	if err != nil {
		return Progress{}, err
	}
	if state.Decision == DecisionRejected {
		return Progress{}, fmt.Errorf("cold start import was rejected")
	}
	if err := ctx.Err(); err != nil {
		return progressFromState(state), err
	}
	if service.candidates == nil {
		if service.options.Discover == nil {
			return Progress{}, fmt.Errorf("cold start discovery unavailable")
		}
		service.candidates, err = service.options.Discover(ctx)
		if err != nil {
			return Progress{}, err
		}
		sortCandidates(service.candidates)
	}
	state.Total = len(service.candidates)
	imported := make(map[string]struct{}, len(state.ImportedLocators))
	for _, locator := range state.ImportedLocators {
		imported[locator] = struct{}{}
	}
	failed := make(map[string]struct{}, len(state.Failures))
	for _, failure := range state.Failures {
		failed[failure.Locator] = struct{}{}
	}
	for _, candidate := range service.candidates {
		if _, exists := imported[candidate.Locator]; exists {
			continue
		}
		if _, exists := stored[candidate.Locator]; exists {
			state.ImportedLocators = append(state.ImportedLocators, candidate.Locator)
			imported[candidate.Locator] = struct{}{}
			continue
		}
	}
	pending := selectPendingBatch(service.candidates, imported, failed, service.importConcurrency())
	if len(pending) > 0 {
		results := make([]candidateImportResult, len(pending))
		var wait sync.WaitGroup
		wait.Add(len(pending))
		for index, candidate := range pending {
			go func() {
				defer wait.Done()
				candidateCtx, cancel := context.WithTimeout(ctx, service.candidateTimeout())
				defer cancel()
				results[index].model, results[index].err = importCandidate(candidateCtx, service.options.Importer, candidate)
			}()
		}
		wait.Wait()
		if err := ctx.Err(); err != nil {
			return progressFromState(state), err
		}
		for index, candidate := range pending {
			if err := ctx.Err(); err != nil {
				return progressFromState(state), err
			}
			importErr := results[index].err
			if importErr == nil {
				importErr = storeCandidate(ctx, service.options.Store, results[index].model)
			}
			if err := ctx.Err(); err != nil {
				return progressFromState(state), err
			}
			if importErr != nil {
				state.Failures = append(state.Failures, Failure{Locator: candidate.Locator, Reason: failureReason(importErr)})
			} else {
				state.ImportedLocators = append(state.ImportedLocators, candidate.Locator)
			}
		}
		state.Total, state.Decision = importCompletion(state, service.candidates)
		if err := ctx.Err(); err != nil {
			return progressFromState(state), err
		}
		if err := service.writeState(state); err != nil {
			return Progress{}, err
		}
		return progressFromState(state), nil
	}
	if err := ctx.Err(); err != nil {
		return progressFromState(state), err
	}
	state.Total, state.Decision = importCompletion(state, service.candidates)
	if err := service.writeState(state); err != nil {
		return Progress{}, err
	}
	return progressFromState(state), nil
}

func (service *Service) RetryFailures(ctx context.Context) (Progress, error) {
	service.mu.Lock()
	defer service.mu.Unlock()
	state, _, err := service.readReconciledState(ctx)
	if err != nil {
		return Progress{}, err
	}
	if state.Decision == DecisionRejected {
		return Progress{}, fmt.Errorf("cold start import was rejected")
	}
	if err := ctx.Err(); err != nil {
		return progressFromState(state), err
	}
	if len(state.Failures) == 0 {
		return progressFromState(state), nil
	}
	state.Decision = DecisionPending
	state.Failures = []Failure{}
	if err := service.writeState(state); err != nil {
		return Progress{}, err
	}
	return progressFromState(state), nil
}

func (service *Service) importConcurrency() int {
	concurrency := service.options.ImportConcurrency
	if concurrency <= 0 {
		concurrency = defaultImportConcurrency
	}
	if concurrency > maximumImportConcurrency {
		concurrency = maximumImportConcurrency
	}
	return concurrency
}

func (service *Service) candidateTimeout() time.Duration {
	timeout := service.options.CandidateTimeout
	if timeout <= 0 || timeout > defaultCandidateTimeout {
		return defaultCandidateTimeout
	}
	return timeout
}

type candidateImportResult struct {
	model telemetryanalysis.AuthorizedSessionModel
	err   error
}

func importCandidate(ctx context.Context, importer SessionImporter, candidate telemetryanalysis.Candidate) (model telemetryanalysis.AuthorizedSessionModel, err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			err = fmt.Errorf("import session panic: %v", recovered)
		}
		if contextErr := ctx.Err(); contextErr != nil {
			model = telemetryanalysis.AuthorizedSessionModel{}
			err = contextErr
		}
	}()
	if err := ctx.Err(); err != nil {
		return model, err
	}
	return importer.Import(ctx, candidate)
}

func storeCandidate(ctx context.Context, store SessionStore, model telemetryanalysis.AuthorizedSessionModel) (err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			err = fmt.Errorf("import session panic: %v", recovered)
		}
	}()
	return store.Add(ctx, model)
}

func (service *Service) Reject(_ context.Context) error {
	service.mu.Lock()
	defer service.mu.Unlock()
	state, err := service.readState()
	if err != nil {
		return err
	}
	state.Decision = DecisionRejected
	return service.writeState(state)
}

func (service *Service) startDiscovery() {
	service.discovering = true
	discover := service.options.Discover
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		candidates, err := discover(ctx)
		if err == nil {
			sortCandidates(candidates)
		}
		service.mu.Lock()
		defer service.mu.Unlock()
		service.discovering = false
		service.discoveryErr = err
		if err == nil {
			service.candidates = candidates
		}
	}()
}

// copyFailures nunca devuelve nil. `append([]Failure(nil))` sin elementos
// devuelve nil, y una lista nula viaja como `null` hasta la pantalla, que
// exige un array y descarta la respuesta entera: el arranque en frio parecia
// roto mientras el backend importaba correctamente.
func copyFailures(failures []Failure) []Failure {
	result := make([]Failure, len(failures))
	copy(result, failures)
	return result
}

func statusFromState(state persistedState, shouldShow, checking bool) Status {
	found := state.Total
	if found == 0 {
		found = len(state.ImportedLocators) + len(state.Failures)
	}
	return Status{ShouldShow: shouldShow, Checking: checking, Found: found, Imported: len(state.ImportedLocators), Skipped: len(state.Failures), Failures: copyFailures(state.Failures), Decision: state.Decision}
}

func progressFromState(state persistedState) Progress {
	return Progress{Imported: len(state.ImportedLocators), Skipped: len(state.Failures), Total: state.Total, Done: state.Decision == DecisionAccepted, Failures: copyFailures(state.Failures)}
}

func sortCandidates(candidates []telemetryanalysis.Candidate) {
	sort.Slice(candidates, func(i, j int) bool { return candidates[i].Locator < candidates[j].Locator })
}

func failureReason(err error) string {
	if errors.Is(err, context.DeadlineExceeded) {
		return "candidate_timeout"
	}
	reason := strings.TrimSpace(err.Error())
	const maxReasonBytes = 512
	if len(reason) > maxReasonBytes {
		reason = reason[:maxReasonBytes]
	}
	return reason
}

var ErrInvalidColdStartState = errors.New("invalid cold start state")

func (service *Service) readState() (persistedState, error) {
	path := service.options.StatePath
	data, readErr := os.ReadFile(path)
	if readErr != nil && !errors.Is(readErr, os.ErrNotExist) {
		return persistedState{}, fmt.Errorf("read cold start state: %w", readErr)
	}
	if readErr == nil {
		state, err := decodeColdStartState(data)
		if err == nil {
			return state, nil
		}
	}
	backup, backupErr := os.ReadFile(path + ".bak")
	if errors.Is(readErr, os.ErrNotExist) && errors.Is(backupErr, os.ErrNotExist) {
		return persistedState{Decision: DecisionPending, ImportedLocators: []string{}, Failures: []Failure{}}, nil
	}
	if backupErr != nil {
		return persistedState{}, fmt.Errorf("%w: backup: %w", ErrInvalidColdStartState, backupErr)
	}
	state, err := decodeColdStartState(backup)
	if err != nil {
		return persistedState{}, err
	}
	if readErr == nil {
		file, err := os.CreateTemp(filepath.Dir(path), filepath.Base(path)+".corrupt-*")
		if err != nil {
			return persistedState{}, fmt.Errorf("create cold start quarantine: %w", err)
		}
		_, writeErr := file.Write(data)
		syncErr := file.Sync()
		closeErr := file.Close()
		if err := errors.Join(writeErr, syncErr, closeErr); err != nil {
			return persistedState{}, fmt.Errorf("preserve cold start quarantine: %w", err)
		}
	}
	if err := writeColdStartFile(path, backup); err != nil {
		return persistedState{}, err
	}
	service.recovered = true
	return state, nil
}

func decodeColdStartState(data []byte) (persistedState, error) {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	var state persistedState
	if err := decoder.Decode(&state); err != nil || decoder.Decode(&struct{}{}) != io.EOF {
		return persistedState{}, ErrInvalidColdStartState
	}
	if state.Decision != DecisionPending && state.Decision != DecisionAccepted && state.Decision != DecisionRejected {
		return persistedState{}, ErrInvalidColdStartState
	}
	if state.ImportedLocators == nil {
		state.ImportedLocators = []string{}
	}
	if state.Failures == nil {
		state.Failures = []Failure{}
	}
	for _, failure := range state.Failures {
		if failure.Locator == "" || failure.Reason == "" {
			return persistedState{}, ErrInvalidColdStartState
		}
	}
	return state, nil
}

func (service *Service) writeState(state persistedState) error {
	data, err := json.Marshal(state)
	if err != nil {
		return fmt.Errorf("encode cold start state: %w", err)
	}
	previous, err := os.ReadFile(service.options.StatePath)
	if errors.Is(err, os.ErrNotExist) {
		previous = data
	} else if err != nil {
		return fmt.Errorf("read cold start backup source: %w", err)
	} else if _, err := decodeColdStartState(previous); err != nil {
		return err
	}
	if err := writeColdStartFile(service.options.StatePath+".bak", previous); err != nil {
		return err
	}
	return writeColdStartFile(service.options.StatePath, data)
}

func writeColdStartFile(path string, data []byte) error {
	directory := filepath.Dir(path)
	if err := os.MkdirAll(directory, 0o700); err != nil {
		return fmt.Errorf("create cold start state directory: %w", err)
	}
	temporary, err := os.CreateTemp(directory, ".strategy-cold-start-*.tmp")
	if err != nil {
		return fmt.Errorf("create cold start temporary: %w", err)
	}
	temporaryPath := temporary.Name()
	defer os.Remove(temporaryPath)
	if err := temporary.Chmod(0o600); err != nil {
		temporary.Close()
		return err
	}
	if _, err := temporary.Write(data); err != nil {
		temporary.Close()
		return err
	}
	if err := temporary.Sync(); err != nil {
		temporary.Close()
		return err
	}
	if err := temporary.Close(); err != nil {
		return err
	}
	if err := os.Rename(temporaryPath, path); err != nil {
		return fmt.Errorf("replace cold start state: %w", err)
	}
	return nil
}
