// Package overlayv2 defines the compact Overlay wire contract. It is additive:
// Overlay v1 remains the production contract until the migration gate closes.
package overlayv2

import "encoding/json"

const (
	ContractVersionV2  uint16 = 2
	AlgorithmVersionV2 uint16 = 2
)

// Quality preserves whether a compact value is usable without repeating the
// complete canonical Field envelope on every wire cell.
type Quality string

const (
	QualityFresh   Quality = "fresh"
	QualityStale   Quality = "stale"
	QualityMissing Quality = "missing"
	QualityInvalid Quality = "invalid"
)

// QValue is the compact wire representation of one quality-bearing value.
// A fresh zero may omit v; q still distinguishes it from a missing value.
type QValue[T any] struct {
	V T       `json:"v,omitempty,omitzero"`
	Q Quality `json:"q"`
}

type Authority string

const (
	AuthorityNative    Authority = "native"
	AuthorityDerived   Authority = "derived"
	AuthorityEstimated Authority = "estimated"
)

type Mode string

const (
	ModeNone          Mode = "none"
	ModeOfficial      Mode = "official"
	ModeReconstructed Mode = "reconstructed"
	ModeEstimated     Mode = "estimated"
	// ModeXYZ is the spotter's: the verdict came from full 3D positions
	// rotated into the player's frame, the strongest spatial mode the spec
	// enumerates (xyz > xy > lap-distance > none).
	ModeXYZ Mode = "xyz"
)

type SpeedUnit string

const (
	SpeedUnitMPS SpeedUnit = "mps"
	SpeedUnitKPH SpeedUnit = "kph"
	SpeedUnitMPH SpeedUnit = "mph"
)

type TemperatureUnit string

const (
	TemperatureUnitCelsius    TemperatureUnit = "celsius"
	TemperatureUnitFahrenheit TemperatureUnit = "fahrenheit"
)

type PressureUnit string

const (
	PressureUnitKPA PressureUnit = "kpa"
	PressureUnitPSI PressureUnit = "psi"
)

type FuelUnit string

const (
	FuelUnitLiters    FuelUnit = "liters"
	FuelUnitGallonsUS FuelUnit = "gallons-us"
)

// SourceStateV2 is the closed simulator-neutral lifecycle exposed to Overlay.
// Keep it aligned with driver.State without importing a concrete driver into
// the projection contract.
type SourceStateV2 string

const (
	SourceStateStopped    SourceStateV2 = "stopped"
	SourceStateDetecting  SourceStateV2 = "detecting"
	SourceStateConnecting SourceStateV2 = "connecting"
	SourceStateLive       SourceStateV2 = "live"
	SourceStateDegraded   SourceStateV2 = "degraded"
	SourceStateStale      SourceStateV2 = "stale"
	SourceStateError      SourceStateV2 = "error"
	SourceStateStopping   SourceStateV2 = "stopping"
)

func (state SourceStateV2) Known() bool {
	switch state {
	case SourceStateStopped, SourceStateDetecting, SourceStateConnecting, SourceStateLive,
		SourceStateDegraded, SourceStateStale, SourceStateError, SourceStateStopping:
		return true
	default:
		return false
	}
}

type UnitsV2 struct {
	Speed       SpeedUnit       `json:"speed"`
	Temperature TemperatureUnit `json:"temperature"`
	Pressure    PressureUnit    `json:"pressure"`
	Fuel        FuelUnit        `json:"fuel"`
}

type SourceStatusV2 struct {
	State            SourceStateV2 `json:"state"`
	ReconnectAttempt uint32        `json:"retry,omitempty"`
	LastFrameAgeMS   int64         `json:"ageMs,omitempty"`
	DegradedReason   string        `json:"reason,omitempty"`
}

type UpdateV2 struct {
	DeliveryRevision uint64         `json:"revision"`
	Source           SourceStatusV2 `json:"source"`
	Frame            *FrameV2       `json:"frame"`
}

type FrameV2 struct {
	ContractVersion  uint16 `json:"contract"`
	AlgorithmVersion uint16 `json:"algorithm"`
	StreamEpoch      uint64 `json:"epoch"`
	SourceSequence   uint64 `json:"sequence"`
	// SectionBuildMask marks the sections rebuilt from SourceSequence. A clear
	// bit means that section is the memoized value from an earlier source tick.
	SectionBuildMask uint16              `json:"sectionMask"`
	SessionID        string              `json:"sessionId"`
	GeneratedAt      string              `json:"generatedAt"`
	Units            UnitsV2             `json:"units"`
	Session          SessionV2           `json:"session"`
	Player           PlayerInstrumentsV2 `json:"player"`
	Controls         ControlsV2          `json:"controls"`
	Standings        []StandingRowV2     `json:"standings"`
	Relative         []RelativeRowV2     `json:"relative"`
	// RelativeSettled is the bounded, membership-settled form of Relative. The
	// reference projector publishes Relative here; only CachedProjector owns
	// the historical authority needed to settle it.
	RelativeSettled []RelativeRowV2 `json:"relativeSettled"`
	// RelativeSameClass is the independently selected, bounded immediate class window.
	RelativeSameClass []RelativeRowV2 `json:"relativeSameClass"`
	Delta             DeltaViewV2     `json:"delta"`
	Fuel              FuelViewV2      `json:"fuel"`
	Spotter           SpotterViewV2   `json:"spotter"`
	Radar             RadarViewV2     `json:"radar"`
	Damage            DamageViewV2    `json:"damage"`
	Weather           WeatherV2       `json:"weather"`
	Capabilities      CapabilitiesV2  `json:"capabilities"`
}

type SessionV2 struct {
	Track            QValue[string]  `json:"track"`
	Phase            QValue[string]  `json:"phase"`
	Flag             QValue[string]  `json:"flag"`
	RemainingSeconds QValue[float64] `json:"remaining"`
	MaximumLaps      QValue[int32]   `json:"maxLaps"`
}

type PlayerInstrumentsV2 struct {
	// Canonical current lap of the player; distinct from completed standings laps.
	LapNumber QValue[int32]   `json:"lapNumber,omitempty"`
	VehicleID string          `json:"id,omitempty"`
	Speed     QValue[float64] `json:"speed"`
	RPM       QValue[float64] `json:"rpm"`
	Gear      QValue[int32]   `json:"gear"`
	Throttle  QValue[float64] `json:"throttle"`
	Brake     QValue[float64] `json:"brake"`
	Clutch    QValue[float64] `json:"clutch"`
	Steering  QValue[float64] `json:"steering"`
}

// ControlsHistoryV2 carries the player's recent control series. It is the
// player alone, never the grid: one row per canonical tick, always
// index-aligned across all seven arrays.
//
// The wire form keeps three parallel per-mille pedal arrays (0..1000, three
// decimals) plus one absolute capture instant per sample and three
// quality-bearing motion series. Parallel arrays cost one number per pedal
// sample instead of an object with keys; each motion cell carries its own
// quality so a missing value omits V without shortening any array.
//
// CapturedAtMS holds absolute Unix epoch milliseconds taken from each
// sample's real capture instant. Absolute instants are cache-safe:
// CachedProjector reuses memoized sections across several frame.GeneratedAt
// values, so a relative age would change meaning while memoized. SpeedMPS
// travels in the source unit m/s; km/h is presentation only in the decoder.
type ControlsHistoryV2 struct {
	Q            Quality           `json:"q"`
	CapturedAtMS []int64           `json:"capturedAtMS,omitempty"`
	Throttle     []int16           `json:"throttle,omitempty"`
	Brake        []int16           `json:"brake,omitempty"`
	Clutch       []int16           `json:"clutch,omitempty"`
	SpeedMPS     []QValue[float64] `json:"speedMPS,omitempty"`
	RPM          []QValue[float64] `json:"rpm,omitempty"`
	Gear         []QValue[int32]   `json:"gear,omitempty"`
}

type ControlsV2 struct {
	History ControlsHistoryV2 `json:"history"`
}

type GroundPositionV2 struct {
	X float64 `json:"x"`
	Z float64 `json:"z"`
}

type WeatherV2 struct {
	AmbientC    QValue[float64] `json:"ambientC"`
	TrackC      QValue[float64] `json:"trackC"`
	RainPercent QValue[float64] `json:"rainPercent"`
	WetnessPct  QValue[float64] `json:"wetnessPct"`
	WindKph     QValue[float64] `json:"windKph"`
	WindDir     QValue[string]  `json:"windDir"`
	PressureHpa QValue[float64] `json:"pressureHpa"`
}

type StandingQualityV2 struct {
	// Timing overrides exist only in the compact wire form; QValue owns them in process.
	Gap           Quality `json:"gap,omitempty"`
	BestLap       Quality `json:"bestLap,omitempty"`
	LastLap       Quality `json:"lastLap,omitempty"`
	Q             Quality `json:"q"`
	Position      Quality `json:"position,omitempty"`
	ClassPosition Quality `json:"classPosition,omitempty"`
	Pit           Quality `json:"pit,omitempty"`
	Laps          Quality `json:"laps,omitempty"`
	GapLaps       Quality `json:"gapLaps,omitempty"`
	ClassGap      Quality `json:"classGap,omitempty"`
	ClassGapLaps  Quality `json:"classGapLaps,omitempty"`
	Interval      Quality `json:"interval,omitempty"`
	IntervalLaps  Quality `json:"intervalLaps,omitempty"`
}

type StandingRowV2 struct {
	// Quality explicitly declares a base for legacy scalar fields; per-field
	// overrides preserve mixed freshness without repeating every fresh string.
	Quality StandingQualityV2 `json:"q,omitempty"`
	// ClassRef is the authoritative absolute position of the class leader in
	// this frame, never an array index. Missing reference means unknown.
	ClassGap                  float64                  `json:"cg,omitempty"`
	ClassGapLaps              int32                    `json:"cl,omitempty"`
	ClassGapReferencePosition int32                    `json:"cr,omitempty"`
	Interval                  float64                  `json:"i,omitempty"`
	IntervalLaps              int32                    `json:"il,omitempty"`
	VehicleID                 string                   `json:"id"`
	Position                  int32                    `json:"position"`
	ClassPosition             int32                    `json:"classPosition"`
	ClassID                   string                   `json:"classId,omitempty"`
	DriverName                string                   `json:"driver,omitempty"`
	CarNumber                 string                   `json:"number,omitempty"`
	GapSeconds                QValue[float64]          `json:"gap"`
	GapLaps                   int32                    `json:"gapLaps,omitempty"`
	PitState                  string                   `json:"pit,omitempty"`
	CompletedLaps             int32                    `json:"laps"`
	BestLapSeconds            QValue[float64]          `json:"bestLap"`
	LastLapSeconds            QValue[float64]          `json:"lastLap"`
	LapDistance               *QValue[float64]         `json:"lapDistance,omitempty"`
	GroundPosition            QValue[GroundPositionV2] `json:"groundPosition"`
}

type RelativeRowV2 struct {
	CarNumber      string          `json:"number,omitempty"`
	BestLapSeconds QValue[float64] `json:"bestLap"`
	VehicleID      string          `json:"id"`
	Position       int32           `json:"position"`
	GapSeconds     QValue[float64] `json:"gap"`
	// LapDelta is the classification lap difference: positive means the rival has
	// more laps than the player, independent of physical side or temporal gap.
	LapDelta       QValue[int32]   `json:"lapDelta"`
	LastLapSeconds QValue[float64] `json:"lastLap"`
	Side           string          `json:"side"`
	Authority      Authority       `json:"authority,omitempty"`
	DisplayName    string          `json:"name,omitempty"`
	ClassID        string          `json:"classId,omitempty"`
}

// DeltaReferenceViewV2 resolves one widget reference request in Go.
// Exactly three resolutions share the frame, without copying the history.
type DeltaReferenceViewV2 struct {
	Requested string          `json:"requested"`
	Reference string          `json:"reference,omitempty"`
	Seconds   QValue[float64] `json:"seconds"`
	Authority Authority       `json:"authority,omitempty"`
}

type DeltaViewV2 struct {
	References []DeltaReferenceViewV2 `json:"references,omitempty"`
	Seconds    QValue[float64]        `json:"seconds"`
	Reference  string                 `json:"reference,omitempty"`
	Requested  string                 `json:"requested,omitempty"`
	Available  []string               `json:"available"`
	Trend      string                 `json:"trend,omitempty"`
	Authority  Authority              `json:"authority,omitempty"`
	History    DeltaHistoryV2         `json:"history"`
}

// DeltaHistoryV2 carries the player's recent delta series. It is the player
// alone, never the grid: one entry per canonical delta sample at the 100 ms
// sampling interval, always index-aligned across both arrays, oldest first,
// capped at 120 (derive.MaxSelfDeltaHistory).
//
// The wire form keeps one absolute capture instant plus one delta figure per
// sample. CapturedAtMS holds absolute Unix epoch milliseconds taken from
// each sample's real capture instant, never a relative age: the delta
// section can be served memoized across several frame.GeneratedAt values,
// so a relative age would change meaning while memoized. Seconds travels
// unquantized, exactly as derive measured it. A series with no usable
// quality publishes its quality with no entries: there are no sentinels and
// no shortened arrays, only fewer entries. SourceTime and LapDistance are
// not transported: the only delta-history consumer (delta-trace) reads
// {capturedAt, deltaSeconds}, proven by inventory with zero wire consumers
// of those fields.
type DeltaHistoryV2 struct {
	Q            Quality   `json:"q"`
	CapturedAtMS []int64   `json:"capturedAtMS,omitempty"`
	Seconds      []float64 `json:"seconds,omitempty"`
}

// FuelBasis names the arithmetic behind FuelViewV2.EstimatedLaps.
type FuelBasis string

const (
	// FuelBasisFuel is floor(remaining / perLap): the laps the tank allows.
	FuelBasisFuel FuelBasis = "fuel"
	// FuelBasisSession is ceil(sessionRemaining / lastLapTime): the laps the
	// session has left at the last lap pace, which is what Overlay v1 showed.
	FuelBasisSession FuelBasis = "session"
)

type FuelViewV2 struct {
	Remaining     QValue[float64] `json:"remaining"`
	Capacity      QValue[float64] `json:"capacity"`
	PerLap        QValue[float64] `json:"perLap"`
	EstimatedLaps QValue[float64] `json:"estimatedLaps"`
	Basis         FuelBasis       `json:"basis,omitempty"`
	// SessionLaps is the laps the session still has left at the last lap
	// pace, always published from SessionRemaining + player LastLapTime even
	// when the fuel basis wins EstimatedLaps. Unit agnostic: laps are laps.
	SessionLaps QValue[float64] `json:"sessionLaps"`
	// RequiredFuel is PerLap x SessionLaps in the preferred fuel unit, never
	// derived from EstimatedLaps: once the fuel basis wins, EstimatedLaps
	// carries the laps the tank allows, not the laps the session has left.
	RequiredFuel QValue[float64] `json:"requiredFuel"`
	History      FuelHistoryV2   `json:"history"`
}

// FuelHistoryV2 carries the player's measured per-lap fuel series. It is the
// player alone, never the grid: one entry per canonical measured lap, always
// index-aligned across both arrays, oldest first, capped at 64.
//
// The wire form keeps one lap number plus one consumption figure per sample.
// Parallel arrays cost one number per sample instead of an object with keys;
// consumption is in the frame unit (frame.units.fuel): derive/ keeps canonical
// litres and the projection converts exactly once, so litres and gallons never
// mix on the wire. A lap with no measurement has no entry: there are no
// sentinels and no shortened arrays, only fewer entries.
type FuelHistoryV2 struct {
	Q        Quality   `json:"q"`
	Lap      []int32   `json:"lap,omitempty"`
	Consumed []float64 `json:"consumed,omitempty"`
}

type SpotterViewV2 struct {
	Mode  Mode         `json:"mode"`
	Left  QValue[bool] `json:"left"`
	Right QValue[bool] `json:"right"`
}

// RadarViewV2 contains only fresh, nearby LMU spatial observations rotated
// into the player's frame. Positive X is left; positive Z is ahead, in metres.
type RadarViewV2 struct {
	Mode Mode         `json:"mode"`
	Cars []RadarCarV2 `json:"cars"`
}

type RadarCarV2 struct {
	ID      string  `json:"id"`
	X       float64 `json:"x"`
	Z       float64 `json:"z"`
	Overlap bool    `json:"overlap"`
	Near    bool    `json:"near"`
	Lapped  bool    `json:"lapped"`
}

type DamageViewV2 struct {
	Dents              QValue[[]uint16]   `json:"dents"`
	Overheating        QValue[bool]       `json:"overheating"`
	Detached           QValue[bool]       `json:"detached"`
	WheelDetachedCount QValue[uint8]      `json:"wheelDetachedCount"`
	TyreWear           *QValue[[]float64] `json:"tyreWear,omitempty"`
}

type CapabilityModesV2 struct {
	Spatial   []string `json:"spatial"`
	Delta     []string `json:"delta"`
	Standings Mode     `json:"standings"`
	Gaps      Mode     `json:"gaps"`
}

type PerformanceModeV2 string

const (
	PerformanceModeManual PerformanceModeV2 = "manual"
	PerformanceModeCustom PerformanceModeV2 = "custom"
	PerformanceModeAuto   PerformanceModeV2 = "auto"
)

type PerformanceEffectsV2 string

const (
	PerformanceEffectsFull   PerformanceEffectsV2 = "full"
	PerformanceEffectsNoBlur PerformanceEffectsV2 = "noBlur"
	PerformanceEffectsFlat   PerformanceEffectsV2 = "flat"
)

type PerformanceReasonV2 string

const (
	PerformanceReasonCPU         PerformanceReasonV2 = "cpu"
	PerformanceReasonFrameTime   PerformanceReasonV2 = "frametime"
	PerformanceReasonUser        PerformanceReasonV2 = "user"
	PerformanceReasonVR          PerformanceReasonV2 = "vr"
	PerformanceReasonUnavailable PerformanceReasonV2 = "unavailable"
)

// PerformanceV2 es la politica efectiva decidida por Go. WidgetHz usa JSON
// crudo solo para conservar la union cerrada number | dirty | event en wire.
type PerformanceV2 struct {
	Level    uint8                      `json:"level"`
	Mode     PerformanceModeV2          `json:"mode"`
	Effects  PerformanceEffectsV2       `json:"effects"`
	RafCap   *int                       `json:"rafCap"`
	WidgetHz map[string]json.RawMessage `json:"widgetHz"`
	Reason   PerformanceReasonV2        `json:"reason,omitempty"`
	SourceHz float64                    `json:"sourceHz"`
}

type CapabilitiesV2 struct {
	Supported   []string           `json:"supported"`
	Available   map[string]Quality `json:"available"`
	Modes       CapabilityModesV2  `json:"modes"`
	Performance *PerformanceV2     `json:"performance,omitempty"`
}
