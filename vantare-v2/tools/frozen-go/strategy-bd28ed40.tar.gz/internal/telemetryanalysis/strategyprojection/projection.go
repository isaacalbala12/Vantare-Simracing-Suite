package strategyprojection

import (
	"math"
	"strings"
	"time"
)

// StrategyInputProjectionV2 es el contrato que Analysis produce en F3a.
// Familias degradadas por D19/informe F0-1:
//
//   - CombinedStintPaceCurve con identifiability (combined_only por defecto)
//   - Pit degradado: ObservedPitLaneInterval + tasas observadas, con trafico/servicio manual
//   - Ahorro con procedencia manual (A5 INVALID)
//   - Clima por buckets de Path Wetness (D5): seco/humedo/mojado, booleanos no informativos descartados
//   - Degradacion por eje/rueda (corner futuro condicionado a mapping versionado)
type StrategyInputProjectionV2 struct {
	ContractVersion    ContractVersion       `json:"contractVersion"`
	GeneratedAt        time.Time             `json:"generatedAt"`
	ComputationVersion string                `json:"computationVersion"`
	SourceSessions     []string              `json:"sourceSessions"`
	SourceRevisions    []AnalysisRevisionRef `json:"sourceRevisions,omitempty"`
	CombinationID      string                `json:"combinationId"`

	// Familias. Cada una lleva sus tres ejes; una familia ausente queda con
	// Presence=missing/unsupported y no bloquea las demas.
	SessionClassification    SessionClassificationFamily `json:"sessionClassification"`
	LapValidity              LapValidityFamily           `json:"lapValidity"`
	FuelConsumption          ResourceConsumptionFamily   `json:"fuelConsumption"`
	VirtualEnergyConsumption ResourceConsumptionFamily   `json:"virtualEnergyConsumption"`
	// RepresentativePaceByClimateBucket conserva el ritmo base observado por
	// condicion sin exigir la identificabilidad de una curva de stint.
	RepresentativePaceByClimateBucket map[ClimateBucket]RepresentativePaceFamily `json:"representativePaceByClimateBucket"`
	// ClassPace prepara la entrada de una fuente compartida futura. Analysis no
	// la deriva de la telemetria del piloto: el productor actual siempre la
	// publica ausente y con procedencia reference.
	ClassPace              *ClassPaceFamily       `json:"classPace,omitempty"`
	CombinedStintPaceCurve CombinedStintPaceCurve `json:"combinedStintPaceCurve"`
	// Curvas separadas solo si identifiability==separable.
	FuelWeightCurve *SeparableCurve `json:"fuelWeightCurve,omitempty"`
	TyreAgeCurve    *SeparableCurve `json:"tyreAgeCurve,omitempty"`

	TyreDegradation TyreDegradationFamily `json:"tyreDegradation"`
	Pit             PitFamily             `json:"pit"`
	SavingCost      SavingCostFamily      `json:"savingCost"`
	ClimateBuckets  ClimateBucketsFamily  `json:"climateBuckets"`
	Temporal        TemporalSegmentsV1    `json:"temporal"`
}

// SessionClassificationFamily (A3 VALID tras spot-check). Seis campos de identidad
// presentes en 336/336; sesiones cortas/sin vuelta -> identificada pero no utilizable.
type SessionClassificationFamily struct {
	Presence          Presence   `json:"presence"`
	Provenance        Provenance `json:"provenance"`
	Confidence        Confidence `json:"confidence"`
	Reason            string     `json:"reason,omitempty"`
	TrackName         string     `json:"trackName"`
	TrackLayout       string     `json:"trackLayout"`
	CarName           string     `json:"carName"`
	CarClass          string     `json:"carClass"`
	SessionType       string     `json:"sessionType"`
	WeatherConditions string     `json:"weatherConditions"`
	UsableForFamilies []string   `json:"usableForFamilies"`
}

// LapValidityFamily: exclusion con motivo; etiqueta out/in-lap, pit, incidente, trafico (D7).
type LapValidityFamily struct {
	Presence   Presence      `json:"presence"`
	Provenance Provenance    `json:"provenance"`
	Confidence Confidence    `json:"confidence"`
	Reason     string        `json:"reason,omitempty"`
	Laps       []LapValidity `json:"laps"`
}

type LapValidity struct {
	SessionID string   `json:"sessionId,omitempty"`
	LapNumber int      `json:"lapNumber"`
	Included  bool     `json:"included"`
	Reason    string   `json:"reason"`
	Tags      []string `json:"tags"`
}

// ResourceConsumptionFamily: media/rango/varianza/confianza por condicion de clima y mezcla.
type ResourceConsumptionFamily struct {
	Presence        Presence                  `json:"presence"`
	Provenance      Provenance                `json:"provenance"`
	Confidence      Confidence                `json:"confidence"`
	Reason          string                    `json:"reason,omitempty"`
	MeanPerLap      float64                   `json:"meanPerLap"`
	RangeLower      float64                   `json:"rangeLower"`
	RangeUpper      float64                   `json:"rangeUpper"`
	ByClimateBucket map[ClimateBucket]float64 `json:"byClimateBucket,omitempty"`
	ByMixture       map[int]float64           `json:"byMixture,omitempty"`
}

// RepresentativePaceFamily es la mediana de vueltas completas utilizables de
// un bucket. No modela degradacion: esa responsabilidad sigue en
// CombinedStintPaceCurve.
type RepresentativePaceFamily struct {
	Presence         Presence   `json:"presence"`
	Provenance       Provenance `json:"provenance"`
	Confidence       Confidence `json:"confidence"`
	Reason           string     `json:"reason,omitempty"`
	MedianLapSeconds float64    `json:"medianLapSeconds"`
}

// ClassPaceReason es el vocabulario cerrado de ausencia del ritmo por clase.
// Se ampliara junto con el contrato cuando exista una fuente compartida real.
type ClassPaceReason string

const (
	ClassPaceReasonNoSource ClassPaceReason = "no_class_pace_source"
)

func (r ClassPaceReason) Valid() bool {
	return r == ClassPaceReasonNoSource
}

// ClassPaceFamily contiene un ritmo de vuelta por nombre de clase. Los valores
// solo pueden proceder de la futura referencia compartida; no son telemetria
// del piloto ni una estimacion de Analysis.
type ClassPaceFamily struct {
	Presence    Presence           `json:"presence"`
	Provenance  Provenance         `json:"provenance"`
	Confidence  Confidence         `json:"confidence"`
	Reason      ClassPaceReason    `json:"reason,omitempty"`
	ByClassName map[string]float64 `json:"byClassName"`
}

// CombinedStintPaceCurve: curva combinada obligatoria. Identifiability por defecto combined_only.
type CombinedStintPaceCurve struct {
	Presence        Presence        `json:"presence"`
	Provenance      Provenance      `json:"provenance"`
	Confidence      Confidence      `json:"confidence"`
	Identifiability Identifiability `json:"identifiability"`
	Reason          string          `json:"reason,omitempty"`
	Points          []PacePoint     `json:"points"`
}

// SeparableCurve solo se publica si identifiability==separable tras gate.
type SeparableCurve struct {
	Presence            Presence    `json:"presence"`
	Provenance          Provenance  `json:"provenance"`
	Confidence          Confidence  `json:"confidence"`
	SlopeSecondsPerUnit float64     `json:"slopeSecondsPerUnit"`
	Points              []PacePoint `json:"points"`
}

type PacePoint struct {
	LapInStint   int      `json:"lapInStint"`
	DeltaSeconds float64  `json:"deltaSeconds"`
	SampleSize   int      `json:"sampleSize"`
	RangeLower   *float64 `json:"rangeLower,omitempty"`
	RangeUpper   *float64 `json:"rangeUpper,omitempty"`
}

// TyreDegradationFamily por eje/rueda (corner futuro condicionado).
type TyreDegradationFamily struct {
	Presence             Presence              `json:"presence"`
	Provenance           Provenance            `json:"provenance"`
	Confidence           Confidence            `json:"confidence"`
	Reason               string                `json:"reason,omitempty"`
	ByAxle               map[TyreAxle]float64  `json:"byAxle,omitempty"`
	ByWheel              map[TyreWheel]float64 `json:"byWheel,omitempty"`
	ByCorner             map[string]float64    `json:"byCorner,omitempty"`
	LifeLapsEstimate     *int                  `json:"lifeLapsEstimate,omitempty"`
	LifeLapsByWheel      map[TyreWheel]float64 `json:"lifeLapsByWheel,omitempty"`
	LifeLapsRangeLower   *float64              `json:"lifeLapsRangeLower,omitempty"`
	LifeLapsRangeUpper   *float64              `json:"lifeLapsRangeUpper,omitempty"`
	LifeThresholdPercent float64               `json:"lifeThresholdPercent,omitempty"`
	CompoundPresence     Presence              `json:"compoundPresence"`
	CompoundMappingNote  string                `json:"compoundMappingNote"`
}

type TyreAxle string

const (
	TyreAxleFront TyreAxle = "front"
	TyreAxleRear  TyreAxle = "rear"
)

type TyreWheel string

const (
	TyreWheelFL TyreWheel = "FL"
	TyreWheelFR TyreWheel = "FR"
	TyreWheelRL TyreWheel = "RL"
	TyreWheelRR TyreWheel = "RR"
)

// PitFamily degradado: ObservedPitLaneInterval + tasas observadas (A4 INVALID -> ramas degradadas).
// Breakdown exacto condicionado a reloj comun y marcadores (futuro). Transito/servicio manual.
type PitFamily struct {
	Presence             Presence                  `json:"presence"`
	Provenance           Provenance                `json:"provenance"`
	Confidence           Confidence                `json:"confidence"`
	Reason               string                    `json:"reason,omitempty"`
	ObservedIntervals    []ObservedPitLaneInterval `json:"observedIntervals"`
	FuelRate             ObservedRateFamily        `json:"fuelRate"`
	VERate               ObservedRateFamily        `json:"veRate"`
	TransitSecondsManual *float64                  `json:"transitSecondsManual,omitempty"`
	ServiceSecondsManual *float64                  `json:"serviceSecondsManual,omitempty"`
	RatesNote            string                    `json:"ratesNote"`
}

type ObservedRateFamily struct {
	Presence   Presence   `json:"presence"`
	Provenance Provenance `json:"provenance"`
	Confidence Confidence `json:"confidence"`
	Reason     string     `json:"reason,omitempty"`
	Mean       float64    `json:"mean"`
}

type ObservedPitLaneInterval struct {
	PitNumber      int        `json:"pitNumber"`
	StartTimestamp *time.Time `json:"startTimestamp,omitempty"`
	EndTimestamp   *time.Time `json:"endTimestamp,omitempty"`
	// Zero means unavailable only for an explicit open_pit_lane_interval.
	DurationSeconds float64  `json:"durationSeconds"`
	FuelAddedLiters *float64 `json:"fuelAddedLiters,omitempty"`
	VEAddedPercent  *float64 `json:"veAddedPercent,omitempty"`
	FuelRateLPerS   *float64 `json:"fuelRateLPerS,omitempty"`
	VERatePPerS     *float64 `json:"veRatePPerS,omitempty"`
	HasFuelRise     bool     `json:"hasFuelRise"`
	HasVERise       bool     `json:"hasVERise"`
	Ambiguous       bool     `json:"ambiguous"`
	AmbiguityReason string   `json:"ambiguityReason,omitempty"`
}

// SavingCostFamily: A5 INVALID -> procedencia manual, derivable solo via protocolo A/B.
type SavingCostFamily struct {
	Presence   Presence      `json:"presence"`
	Provenance Provenance    `json:"provenance"`
	Confidence Confidence    `json:"confidence"`
	Reason     string        `json:"reason,omitempty"`
	ManualNote string        `json:"manualNote"`
	Levels     []SavingLevel `json:"levels,omitempty"`
}

type SavingLevel struct {
	MixtureCode     int     `json:"mixtureCode"`
	FuelSavedPerLap float64 `json:"fuelSavedPerLap"`
	VESavedPerLap   float64 `json:"veSavedPerLap,omitempty"`
	TimeCostPerLap  float64 `json:"timeCostPerLap"`
}

// ClimateBucketsFamily: buckets discretos via Path Wetness (0, 5, 12.5% observados).
type ClimateBucketsFamily struct {
	Presence   Presence             `json:"presence"`
	Provenance Provenance           `json:"provenance"`
	Confidence Confidence           `json:"confidence"`
	Reason     string               `json:"reason,omitempty"`
	Buckets    []ClimateBucketPoint `json:"buckets"`
}

type ClimateBucket string

const (
	ClimateBucketDry   ClimateBucket = "dry"
	ClimateBucketHumid ClimateBucket = "humid"
	ClimateBucketWet   ClimateBucket = "wet"
)

func (b ClimateBucket) Valid() bool {
	switch b {
	case ClimateBucketDry, ClimateBucketHumid, ClimateBucketWet:
		return true
	default:
		return false
	}
}

type ClimateBucketPoint struct {
	Bucket             ClimateBucket `json:"bucket"`
	PathWetnessPercent float64       `json:"pathWetnessPercent"`
	SampleSize         int           `json:"sampleSize"`
}

func (p StrategyInputProjectionV2) Validate() error {
	if p.ContractVersion != ContractVersionStrategyInputProjectionV2 {
		return contractError(
			"unsupported_contract_version",
			"contractVersion",
			"unsupported strategy input projection version",
		)
	}
	if err := ValidateSourceRevisions(p.SourceSessions, p.SourceRevisions); err != nil {
		return err
	}
	if err := validateTimestamp("generatedAt", p.GeneratedAt); err != nil {
		return err
	}
	if p.ComputationVersion == "" {
		return contractError("invalid_document", "computationVersion", "is required")
	}
	for bucket, pace := range p.RepresentativePaceByClimateBucket {
		if !bucket.Valid() {
			return contractError("invalid_document", "representativePaceByClimateBucket", "unknown climate bucket")
		}
		if err := pace.Validate("representativePaceByClimateBucket." + string(bucket)); err != nil {
			return err
		}
	}
	if p.ClassPace != nil {
		if err := p.ClassPace.Validate(); err != nil {
			return err
		}
	}
	if err := p.CombinedStintPaceCurve.Validate(); err != nil {
		return err
	}
	if p.FuelWeightCurve != nil && p.CombinedStintPaceCurve.Identifiability != IdentifiabilitySeparable {
		return contractError("invalid_document", "fuelWeightCurve", "requires separable identifiability")
	}
	if p.FuelWeightCurve != nil {
		if err := p.FuelWeightCurve.Validate("fuelWeightCurve"); err != nil {
			return err
		}
		if p.FuelWeightCurve.SlopeSecondsPerUnit < 0 {
			return contractError("invalid_document", "fuelWeightCurve.slopeSecondsPerUnit", "must be non-negative")
		}
	}
	if p.TyreAgeCurve != nil && p.CombinedStintPaceCurve.Identifiability != IdentifiabilitySeparable {
		return contractError("invalid_document", "tyreAgeCurve", "requires separable identifiability")
	}
	if p.TyreAgeCurve != nil {
		if err := p.TyreAgeCurve.Validate("tyreAgeCurve"); err != nil {
			return err
		}
	}
	// Pit: si no hay reloj comun, breakdown exacto no se publica; solo intervalos.
	// La validacion aqui solo comprueba presencia/provenance/confidence basicos.
	if !p.Pit.Presence.Valid() {
		return contractError("invalid_document", "pit.presence", "unknown presence")
	}
	for _, interval := range p.Pit.ObservedIntervals {
		open := interval.EndTimestamp == nil && interval.DurationSeconds == 0 &&
			interval.Ambiguous && interval.AmbiguityReason == "open_pit_lane_interval" && interval.StartTimestamp != nil
		if interval.DurationSeconds <= 0 && !open {
			return contractError("invalid_document", "pit.observedIntervals", "duration must be positive")
		}
		if open && (interval.HasFuelRise || interval.HasVERise || interval.FuelAddedLiters != nil ||
			interval.VEAddedPercent != nil || interval.FuelRateLPerS != nil || interval.VERatePPerS != nil) {
			return contractError("invalid_document", "pit.observedIntervals", "open pit cannot publish final resources")
		}
		if !interval.HasFuelRise && !interval.HasVERise && !interval.Ambiguous {
			return contractError("invalid_document", "pit.observedIntervals", "pit without resource rise must be ambiguous")
		}
		if interval.Ambiguous && interval.AmbiguityReason == "" {
			return contractError("invalid_document", "pit.observedIntervals", "ambiguous pit requires reason")
		}
		if !interval.HasFuelRise && interval.FuelRateLPerS != nil {
			return contractError("invalid_document", "pit.observedIntervals", "fuel rate requires observed rise")
		}
		if !interval.HasVERise && interval.VERatePPerS != nil {
			return contractError("invalid_document", "pit.observedIntervals", "VE rate requires observed rise")
		}
	}
	return nil
}

func (p RepresentativePaceFamily) Validate(field string) error {
	if !p.Presence.Valid() {
		return contractError("invalid_document", field+".presence", "unknown presence")
	}
	if err := p.Provenance.Validate(); err != nil {
		return err
	}
	if err := p.Confidence.Validate(); err != nil {
		return err
	}
	if p.Presence == PresenceValid {
		if math.IsNaN(p.MedianLapSeconds) || math.IsInf(p.MedianLapSeconds, 0) || p.MedianLapSeconds <= 0 {
			return contractError("invalid_document", field+".medianLapSeconds", "must be positive and finite")
		}
		if p.Confidence.SampleSize <= 0 {
			return contractError("invalid_document", field+".confidence.sampleSize", "must be positive when valid")
		}
		return nil
	}
	if p.Reason == "" {
		return contractError("invalid_document", field+".reason", "is required when representative pace is unavailable")
	}
	return nil
}

func (p ClassPaceFamily) Validate() error {
	const field = "classPace"
	if !p.Presence.Valid() {
		return contractError("invalid_document", field+".presence", "unknown presence")
	}
	if err := p.Provenance.Validate(); err != nil {
		return err
	}
	if p.Provenance.Kind != ProvenanceReference {
		return contractError("invalid_provenance", field+".provenance.kind", "class pace requires reference provenance")
	}
	if err := p.Confidence.Validate(); err != nil {
		return err
	}
	if p.Presence != PresenceValid {
		if !p.Reason.Valid() {
			return contractError("invalid_document", field+".reason", "typed reason is required when class pace is unavailable")
		}
		if len(p.ByClassName) != 0 {
			return contractError("invalid_document", field+".byClassName", "unavailable class pace cannot contain values")
		}
		return nil
	}
	if p.Reason != "" {
		return contractError("invalid_document", field+".reason", "valid class pace cannot declare a missing reason")
	}
	if len(p.ByClassName) == 0 {
		return contractError("invalid_document", field+".byClassName", "valid class pace requires at least one class")
	}
	if p.Confidence.SampleSize <= 0 {
		return contractError("invalid_document", field+".confidence.sampleSize", "must be positive when valid")
	}
	for className, paceSeconds := range p.ByClassName {
		if strings.TrimSpace(className) == "" {
			return contractError("invalid_document", field+".byClassName", "class name is required")
		}
		if math.IsNaN(paceSeconds) || math.IsInf(paceSeconds, 0) || paceSeconds <= 0 {
			return contractError("invalid_document", field+".byClassName."+className, "pace must be positive and finite")
		}
	}
	return nil
}

func (c SeparableCurve) Validate(field string) error {
	if !c.Presence.Valid() {
		return contractError("invalid_document", field+".presence", "unknown presence")
	}
	if err := c.Provenance.Validate(); err != nil {
		return err
	}
	if err := c.Confidence.Validate(); err != nil {
		return err
	}
	if math.IsNaN(c.SlopeSecondsPerUnit) || math.IsInf(c.SlopeSecondsPerUnit, 0) {
		return contractError("invalid_document", field+".slopeSecondsPerUnit", "must be finite")
	}
	return nil
}

func (c CombinedStintPaceCurve) Validate() error {
	if !c.Presence.Valid() {
		return contractError("invalid_document", "combinedStintPaceCurve.presence", "unknown presence")
	}
	if !c.Identifiability.Valid() {
		return contractError("invalid_document", "combinedStintPaceCurve.identifiability", "unknown identifiability")
	}
	if err := c.Provenance.Validate(); err != nil {
		return err
	}
	return c.Confidence.Validate()
}
